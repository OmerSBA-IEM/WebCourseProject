document.addEventListener("DOMContentLoaded", function () {

    // בדיקה אם יש משתמש מחובר
    const currentUser = JSON.parse(localStorage.getItem("currentUser"));

    if (!currentUser || !currentUser.id) {
        localStorage.removeItem("currentUser");
        window.location.href = "index.html";
        return;
    }

    // אלמנטים מהעמוד
    const restaurantName = document.getElementById("restaurantName");
    const restaurantDescription = document.getElementById("restaurantDescription");
    const selectedRestaurantName = document.getElementById("selectedRestaurantName");
    const selectedRestaurantAddress = document.getElementById("selectedRestaurantAddress");
    const menuResults = document.getElementById("menuResults");
    const menuSubtitle = document.getElementById("menuSubtitle");

    const selectedRestaurantId = localStorage.getItem("selectedRestaurantId");
    const selectedCity = localStorage.getItem("selectedCity");

    let userPreferences = {
        dietary: [],
        allergens: [],
        dislikes: []
    };

    // אם לא נבחרה מסעדה
    if (!selectedRestaurantId) {
        showNoRestaurantSelected();
        return;
    }

    // טעינת התפריט הרלוונטי מהשרת
    loadRelevantMenuFromServer();

    // שליפת תפריט רלוונטי מהשרת לפי מסעדה ומשתמש
    function loadRelevantMenuFromServer() {
        menuResults.innerHTML = `
            <div class="empty-state">
                <span>⌖</span>
                <h3>טוען תפריט...</h3>
                <p>אנחנו שולפים מהשרת רק את המנות שמתאימות להעדפות שלך.</p>
            </div>
        `;

        fetch("/api/restaurants/" + selectedRestaurantId + "/menu/relevant?userId=" + currentUser.id)
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                if (!data.success) {
                    showErrorMessage(data.message);
                    return;
                }

                userPreferences = data.userPreferences || {
                    dietary: [],
                    allergens: [],
                    dislikes: []
                };

                renderRestaurantDetails(data.restaurant, data.dishes);
                renderMenuDishes(data.dishes);
                loadRestaurantAddressFromServer();
            })
            .catch(function () {
                showErrorMessage("לא הצלחנו לטעון את התפריט מהשרת.");
            });
    }

    // שליפת כתובת המסעדה לפי העיר שנבחרה
    function loadRestaurantAddressFromServer() {
        if (!selectedCity) {
            selectedRestaurantAddress.textContent = "כתובת לא זמינה";
            return;
        }

        fetch("/api/restaurants?city=" + selectedCity)
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                if (!data.success) {
                    selectedRestaurantAddress.textContent = "כתובת לא זמינה";
                    return;
                }

                const selectedRestaurant = data.restaurants.find(function (restaurant) {
                    return restaurant.id === Number(selectedRestaurantId);
                });

                if (selectedRestaurant && selectedRestaurant.address) {
                    selectedRestaurantAddress.textContent = selectedRestaurant.address;
                } else {
                    selectedRestaurantAddress.textContent = "כתובת לא זמינה";
                }
            })
            .catch(function () {
                selectedRestaurantAddress.textContent = "כתובת לא זמינה";
            });
    }

    // הצגת פרטי המסעדה
    function renderRestaurantDetails(restaurant, dishes) {
        restaurantName.textContent = restaurant.name;
        restaurantDescription.textContent = restaurant.description;

        selectedRestaurantName.textContent = restaurant.name;

        menuSubtitle.textContent =
            "בתפריט של " + restaurant.name + " נמצאו " +
            dishes.length + " מנות רלוונטיות עבורך.";
    }

    // הצגת המנות שהשרת החזיר
    function renderMenuDishes(dishes) {
        menuResults.innerHTML = "";

        if (!dishes || dishes.length === 0) {
            menuResults.innerHTML = `
                <div class="empty-state">
                    <span>⌖</span>
                    <h3>לא נמצאו מנות מתאימות</h3>
                    <p>
                        לא נמצאו מנות שתואמות את ההעדפות שהגדרת.
                        אפשר לחזור לעמוד ההעדפות ולעדכן את הבחירות.
                    </p>
                    <a href="preferences.html" class="back-btn">עדכון העדפות</a>
                </div>
            `;
            return;
        }

        dishes.forEach(function (dish) {
            const relevantNotes = getRelevantNotes(dish);

            const card = document.createElement("article");
            card.className = "dish-card";

            card.innerHTML = `
                <img src="${dish.image}" alt="תמונה של ${dish.name}" onerror="this.src='images/hero-food.jpg'">

                <div>
                    <div class="dish-top-row">
                        <div>
                            <h3>${dish.name}</h3>
                            <p>${dish.description}</p>
                        </div>

                        <div class="dish-price">₪${dish.price}</div>
                    </div>

                    <div class="dish-meta">
                        <span class="meta-pill">${dish.category}</span>
                        ${createDietaryTags(dish.dietary)}
                    </div>

                    ${createDishInfoBox(relevantNotes)}
                </div>
            `;

            menuResults.appendChild(card);
        });
    }

    // מחזיר הערות התאמה שרלוונטיות להעדפות המשתמש
    function getRelevantNotes(dish) {
        const userKeys = getAllUserPreferenceKeys();
        const relevantNotes = [];

        if (!dish.notes) {
            return relevantNotes;
        }

        dish.notes.forEach(function (note) {
            const hasRelevantPreference = note.keys.some(function (key) {
                return userKeys.includes(key);
            });

            if (hasRelevantPreference) {
                relevantNotes.push(note.text);
            }
        });

        return relevantNotes;
    }

    // איחוד כל ההעדפות של המשתמש למערך אחד
    function getAllUserPreferenceKeys() {
        const allKeys = [
            ...userPreferences.dietary,
            ...userPreferences.allergens,
            ...userPreferences.dislikes
        ];

        // התאמות בין העדפות תזונה לבין אלרגנים בפועל
        if (userPreferences.dietary.includes("lactose-free")) {
            allKeys.push("milk");
        }

        if (userPreferences.dietary.includes("gluten-free")) {
            allKeys.push("gluten");
        }

        return allKeys;
    }

    // יצירת קופסת הערות התאמה
    function createDishInfoBox(relevantNotes) {
        if (relevantNotes.length === 0) {
            return "";
        }

        let html = `<div class="dish-info-box">`;

        html += `
            <div class="relevant-notes">
                <p><strong>התאמות רלוונטיות עבורך:</strong></p>
                <ul>
        `;

        relevantNotes.forEach(function (noteText) {
            html += `<li>${noteText}</li>`;
        });

        html += `
                </ul>
            </div>
        `;

        html += `</div>`;

        return html;
    }

    // יצירת תגיות תזונה
    function createDietaryTags(dietaryArray) {
        if (!dietaryArray) {
            return "";
        }

        const labels = {
            "vegan": "טבעוני",
            "vegetarian": "צמחוני",
            "gluten-free": "ללא גלוטן",
            "lactose-free": "ללא לקטוז",
            "kosher": "כשר"
        };

        return dietaryArray.map(function (item) {
            return `<span class="meta-pill">${labels[item] || item}</span>`;
        }).join("");
    }

    // הודעת שגיאה כללית
    function showErrorMessage(message) {
        restaurantName.textContent = "שגיאה בטעינת התפריט";
        restaurantDescription.textContent = "לא הצלחנו לטעון את התפריט כרגע.";

        selectedRestaurantName.textContent = "שגיאה";
        selectedRestaurantAddress.textContent = "";

        menuSubtitle.textContent = "אין תפריט להצגה.";

        menuResults.innerHTML = `
            <div class="empty-state">
                <span>⌖</span>
                <h3>שגיאה בטעינת התפריט</h3>
                <p>${message}</p>
                <a href="restaurants.html" class="back-btn">חזרה לבחירת מסעדה</a>
            </div>
        `;
    }

    // מצב שבו לא נבחרה מסעדה
    function showNoRestaurantSelected() {
        restaurantName.textContent = "לא נבחרה מסעדה";
        restaurantDescription.textContent =
            "כדי לראות תפריט, חזרו לעמוד המסעדות ובחרו מסעדה.";

        selectedRestaurantName.textContent = "לא נבחרה מסעדה";
        selectedRestaurantAddress.textContent = "";

        menuSubtitle.textContent = "אין מסעדה להצגה.";

        menuResults.innerHTML = `
            <div class="empty-state">
                <span>⌖</span>
                <h3>אין מסעדה להצגה</h3>
                <p>חזרו לעמוד בחירת המסעדות ובחרו מסעדה מהרשימה.</p>
                <a href="restaurants.html" class="back-btn">חזרה לבחירת מסעדה</a>
            </div>
        `;
    }

});