document.addEventListener("DOMContentLoaded", function () {

    const currentUser = JSON.parse(localStorage.getItem("currentUser"));

    // אם אין משתמש מחובר, מחזירים לעמוד התחברות
    if (!currentUser || !currentUser.id) {
        localStorage.removeItem("currentUser");
        window.location.href = "index.html";
        return;
    }

    const restaurantPreferencesTitle = document.getElementById("restaurantPreferencesTitle");
    const citySelect = document.getElementById("citySelect");
    const locationForm = document.getElementById("locationForm");
    const locationMessage = document.getElementById("locationMessage");
    const restaurantsList = document.getElementById("restaurantsList");
    const restaurantsSection = document.getElementById("restaurantsSection");
    const resultsTitle = document.getElementById("resultsTitle");
    const resultsSubtitle = document.getElementById("resultsSubtitle");

    if (!citySelect || !locationForm || !restaurantsList) {
        return;
    }

    if (restaurantPreferencesTitle) {
        restaurantPreferencesTitle.textContent = "העדפות של " + (currentUser.fullName || currentUser.username);
    }

    const cityNames = {
        "beer-sheva": "באר שבע",
        "haifa": "חיפה",
        "ashdod": "אשדוד",
        "tel-aviv": "תל אביב"
    };

    let userPreferences = {
        dietary: [],
        allergens: [],
        dislikes: []
    };

    // טעינת העדפות מהשרת
    loadUserPreferencesFromServer();

    // כאשר המשתמש בוחר עיר ולוחץ על הצג מסעדות
    locationForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const selectedCity = citySelect.value;

        if (!selectedCity) {
            restaurantsList.innerHTML = `
                <div class="empty-state">
                    <span>⌖</span>
                    <h3>לא נבחרה עיר</h3>
                    <p>בחרו עיר מהרשימה כדי לראות מסעדות.</p>
                </div>
            `;

            locationMessage.textContent = "צריך לבחור עיר כדי להציג מסעדות.";
            return;
        }

        localStorage.setItem("selectedCity", selectedCity);

        loadRestaurantsFromServer(selectedCity);
    });

    // שליפת מסעדות מהשרת לפי עיר + ספירת מנות רלוונטיות לפי המשתמש
    function loadRestaurantsFromServer(city) {

        locationMessage.textContent = "טוען מסעדות...";

        fetch("/api/restaurants?city=" + city + "&userId=" + currentUser.id)
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                if (!data.success) {
                    restaurantsList.innerHTML = `
                        <div class="empty-state">
                            <span>⌖</span>
                            <h3>שגיאה בטעינת מסעדות</h3>
                            <p>${data.message}</p>
                        </div>
                    `;

                    locationMessage.textContent = data.message;
                    return;
                }

                renderRestaurants(data.restaurants, city);

                restaurantsSection.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });
            })
            .catch(function () {
                restaurantsList.innerHTML = `
                    <div class="empty-state">
                        <span>⌖</span>
                        <h3>שגיאה בשרת</h3>
                        <p>לא הצלחנו לטעון את המסעדות כרגע.</p>
                    </div>
                `;

                locationMessage.textContent = "אירעה שגיאה בטעינת המסעדות מהשרת.";
            });
    }

    // ציור כרטיסי המסעדות בעמוד
    function renderRestaurants(restaurants, city) {
        restaurantsList.innerHTML = "";

        resultsTitle.textContent = "מסעדות ב" + cityNames[city];
        resultsSubtitle.textContent = "בחרו מסעדה כדי לראות את התפריט שלה.";

        locationMessage.textContent =
            "נמצאו " + restaurants.length + " מסעדות באזור שבחרתם.";

        if (restaurants.length === 0) {
            restaurantsList.innerHTML = `
                <div class="empty-state">
                    <span>⌖</span>
                    <h3>לא נמצאו מסעדות</h3>
                    <p>כרגע אין מסעדות זמינות בעיר שבחרתם.</p>
                </div>
            `;
            return;
        }

        restaurants.forEach(function (restaurant) {

            const relevantCount = restaurant.relevantDishesCount || 0;

            const card = document.createElement("article");
            card.className = "restaurant-card";

            card.innerHTML = `
                <img src="${restaurant.logo}" alt="לוגו של ${restaurant.name}" onerror="this.src='images/logo.png'">

                <div>
                    <h3>${restaurant.name}</h3>
                    <p>${restaurant.description}</p>

                    <div class="restaurant-meta">
                        <span class="meta-pill">${restaurant.address || "כתובת לא זמינה"}</span>
                        <span class="meta-pill">${restaurant.cuisine}</span>
                        <span class="meta-pill relevant-count-pill">
                            ${relevantCount} מנות רלוונטיות עבורך
                        </span>
                    </div>
                </div>

                <button class="choose-restaurant-btn" type="button">
                    הצג תפריט
                </button>
            `;

            const button = card.querySelector(".choose-restaurant-btn");

            button.addEventListener("click", function () {
                localStorage.setItem("selectedRestaurantId", restaurant.id);
                localStorage.setItem("selectedCity", city);
                window.location.href = "menu.html";
            });

            restaurantsList.appendChild(card);
        });
    }

    // שליפת העדפות המשתמש מהשרת
    function loadUserPreferencesFromServer() {
        fetch("/api/preferences/" + currentUser.id)
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                if (!data.success) {
                    renderUserPreferencesBox();
                    return;
                }

                userPreferences = {
                    dietary: [],
                    allergens: [],
                    dislikes: []
                };

                data.preferences.forEach(function (preference) {
                    if (preference.type === "dietary") {
                        userPreferences.dietary.push(preference.value);
                    }

                    if (preference.type === "allergens") {
                        userPreferences.allergens.push(preference.value);
                    }

                    if (preference.type === "dislikes") {
                        userPreferences.dislikes.push(preference.value);
                    }
                });

                renderUserPreferencesBox();
            })
            .catch(function () {
                renderUserPreferencesBox();
            });
    }

    // הצגת ההעדפות בצד העמוד
    function renderUserPreferencesBox() {
        const preferencesBox = document.getElementById("restaurantUserPreferences");
        const preferencesText = document.getElementById("restaurantPreferencesText");
        const preferencesLink = document.getElementById("restaurantPreferencesLink");

        if (!preferencesBox) {
            return;
        }

        const preferencesLabels = {
            "vegetarian": "צמחוני",
            "vegan": "טבעוני",
            "gluten-free": "ללא גלוטן",
            "lactose-free": "ללא לקטוז",
            "kosher": "כשר",

            "peanuts": "בוטנים",
            "milk": "חלב",
            "egg": "ביצים",
            "soy": "סויה",
            "sesame": "שומשום",
            "tree-nuts": "אגוזים",
            "fish": "דגים",

            "cilantro": "כוסברה",
            "tomato": "עגבנייה",
            "onion": "בצל",
            "garlic": "שום",
            "mushrooms": "פטריות",
            "eggplant": "חציל",
            "olives": "זיתים",
            "hot-pepper": "פלפל חריף",
            "bell-pepper": "פלפל אדום / גמבה",
            "cucumber": "מלפפון",
            "corn": "תירס",
            "peas": "אפונה",
            "mayonnaise": "מיונז",
            "mustard": "חרדל",
            "tuna": "טונה",
            "cinnamon": "קינמון",
            "dill": "שמיר",
            "parsley": "פטרוזיליה",
            "broccoli": "ברוקולי"
        };

        const allPreferences = [
            ...userPreferences.dietary,
            ...userPreferences.allergens,
            ...userPreferences.dislikes
        ];

        preferencesBox.innerHTML = "";

        if (allPreferences.length === 0) {
            preferencesBox.innerHTML = `
                <p class="empty-preferences-message">
                    עדיין לא הוגדרו העדפות.
                </p>
            `;

            if (preferencesText) {
                preferencesText.textContent = "כדי שנוכל להתאים לך מסעדות ומנות, מומלץ לעדכן את ההעדפות שלך.";
            }

            if (preferencesLink) {
                preferencesLink.innerHTML = `
                    מעבר לעמוד ההעדפות
                    <span>←</span>
                `;
            }

            return;
        }

        allPreferences.forEach(function (preference) {
            const tag = document.createElement("span");
            tag.classList.add("tag");

            if (preferencesLabels[preference]) {
                tag.textContent = preferencesLabels[preference];
            } else {
                tag.textContent = preference;
            }

            preferencesBox.appendChild(tag);
        });

        if (preferencesText) {
            preferencesText.textContent = "ההעדפות האלו משמשות לסינון ולהצגת הערות התאמה רלוונטיות בלבד.";
        }

        if (preferencesLink) {
            preferencesLink.innerHTML = `
                לעדכון העדפות
                <span>←</span>
            `;
        }
    }

});