document.addEventListener("DOMContentLoaded", function () {

    const currentUser = JSON.parse(localStorage.getItem("currentUser"));

    // אם אין משתמש מחובר או שאין לו id מהשרת, מחזירים להתחברות
    if (!currentUser || !currentUser.id) {
        localStorage.removeItem("currentUser");
        window.location.href = "index.html";
        return;
    }

    const preferencesForm = document.getElementById("preferencesForm");
    const preferencesMessage = document.getElementById("preferencesMessage");
    const clearPreferencesBtn = document.getElementById("clearPreferencesBtn");

    if (!preferencesForm) {
        return;
    }

    // טעינת העדפות שכבר נשמרו בשרת
    loadSavedPreferencesFromServer();

    // שמירת העדפות
    preferencesForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const preferences = collectPreferencesFromForm();

        savePreferencesToServer(preferences, true);
    });

    // ניקוי בחירות
    if (clearPreferencesBtn) {
        clearPreferencesBtn.addEventListener("click", function () {
            clearAllCheckboxes();

            savePreferencesToServer([], false);
        });
    }

    // איסוף כל ההעדפות שנבחרו בטופס
    function collectPreferencesFromForm() {
        const preferences = [];

        const dietary = getCheckedValues("dietary");
        const allergens = getCheckedValues("allergens");
        const dislikes = getCheckedValues("dislikes");

        dietary.forEach(function (value) {
            preferences.push({
                type: "dietary",
                value: value
            });
        });

        allergens.forEach(function (value) {
            preferences.push({
                type: "allergens",
                value: value
            });
        });

        dislikes.forEach(function (value) {
            preferences.push({
                type: "dislikes",
                value: value
            });
        });

        return preferences;
    }

    // שליפת כל הערכים המסומנים לפי שם הקבוצה
    function getCheckedValues(groupName) {
        const checkedInputs = document.querySelectorAll("input[name='" + groupName + "']:checked");
        const values = [];

        checkedInputs.forEach(function (input) {
            values.push(input.value);
        });

        return values;
    }

    // שמירת ההעדפות בשרת
    function savePreferencesToServer(preferences, shouldMoveToRestaurantsPage) {
        showMessage("שומרת העדפות...", "success-message");

        fetch("/api/preferences/save", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                userId: currentUser.id,
                preferences: preferences
            })
        })
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                if (!data.success) {
                    showMessage(data.message || "אירעה שגיאה בשמירת ההעדפות בשרת", "clear-message");
                    return;
                }

                savePreferencesInLocalStorage(preferences);

                if (shouldMoveToRestaurantsPage) {
                    showMessage("ההעדפות נשמרו בהצלחה. מעבירים אותך לעמוד המסעדות...", "success-message");

                    setTimeout(function () {
                        window.location.href = "restaurants.html";
                    }, 900);
                } else {
                    showMessage("הבחירות נוקו בהצלחה.", "clear-message");
                }
            })
            .catch(function () {
                showMessage("אירעה שגיאה בשמירת ההעדפות בשרת", "clear-message");
            });
    }

    // טעינת העדפות קיימות מהשרת
    function loadSavedPreferencesFromServer() {
        fetch("/api/preferences/" + currentUser.id)
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                if (!data.success) {
                    return;
                }

                markSavedPreferences(data.preferences);
            })
            .catch(function () {
                showMessage("לא הצלחנו לטעון העדפות קיימות.", "clear-message");
            });
    }

    // סימון הצ'קבוקסים לפי מה שחזר מהשרת
    function markSavedPreferences(preferences) {
        if (!Array.isArray(preferences)) {
            return;
        }

        preferences.forEach(function (preference) {
            const checkbox = document.querySelector(
                "input[name='" + preference.type + "'][value='" + preference.value + "']"
            );

            if (checkbox) {
                checkbox.checked = true;
            }
        });

        savePreferencesInLocalStorage(preferences);
    }

    // ניקוי כל הצ'קבוקסים
    function clearAllCheckboxes() {
        const allCheckboxes = preferencesForm.querySelectorAll("input[type='checkbox']");

        allCheckboxes.forEach(function (checkbox) {
            checkbox.checked = false;
        });
    }

    // שמירה קטנה גם ב-localStorage כדי ששאר העמודים יוכלו להשתמש בזה אם צריך
    function savePreferencesInLocalStorage(preferences) {
        const groupedPreferences = {
            dietary: [],
            allergens: [],
            dislikes: []
        };

        preferences.forEach(function (preference) {
            if (preference.type === "dietary") {
                groupedPreferences.dietary.push(preference.value);
            }

            if (preference.type === "allergens") {
                groupedPreferences.allergens.push(preference.value);
            }

            if (preference.type === "dislikes") {
                groupedPreferences.dislikes.push(preference.value);
            }
        });

        localStorage.setItem("preferences", JSON.stringify(groupedPreferences));
    }

    // הצגת הודעה למשתמש
    function showMessage(message, className) {
        if (!preferencesMessage) {
            return;
        }

        preferencesMessage.textContent = message;
        preferencesMessage.className = "preferences-message";
        preferencesMessage.classList.add(className);
    }

});