document.addEventListener("DOMContentLoaded", function () {

    const loginForm = document.getElementById("loginForm");
    const registerForm = document.getElementById("registerForm");

    const showLoginBtn = document.getElementById("showLoginBtn");
    const showRegisterBtn = document.getElementById("showRegisterBtn");
    const showRegisterTextBtn = document.getElementById("showRegisterTextBtn");
    const showLoginTextBtn = document.getElementById("showLoginTextBtn");

    const loginMessage = document.getElementById("loginMessage");
    const registerMessage = document.getElementById("registerMessage");

    function showLogin() {
        loginForm.classList.remove("hidden");
        registerForm.classList.add("hidden");

        showLoginBtn.classList.add("active-tab");
        showRegisterBtn.classList.remove("active-tab");
    }

    function showRegister() {
        loginForm.classList.add("hidden");
        registerForm.classList.remove("hidden");

        showRegisterBtn.classList.add("active-tab");
        showLoginBtn.classList.remove("active-tab");
    }

    function showMessage(element, message, type) {
        element.textContent = message;
        element.className = "form-message";
        element.classList.add(type);
    }

    if (showLoginBtn) {
        showLoginBtn.addEventListener("click", showLogin);
    }

    if (showRegisterBtn) {
        showRegisterBtn.addEventListener("click", showRegister);
    }

    if (showRegisterTextBtn) {
        showRegisterTextBtn.addEventListener("click", showRegister);
    }

    if (showLoginTextBtn) {
        showLoginTextBtn.addEventListener("click", showLogin);
    }

    // התחברות מול השרת
    if (loginForm) {
        loginForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const username = document.getElementById("loginUsername").value.trim();
            const password = document.getElementById("loginPassword").value;

            showMessage(loginMessage, "", "success");

            fetch("/api/auth/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    username: username,
                    password: password
                })
            })
                .then(function (response) {
                    return response.json();
                })
                .then(function (data) {
                    if (!data.success) {
                        showMessage(loginMessage, data.message, "error");
                        return;
                    }

                    localStorage.setItem("currentUser", JSON.stringify(data.user));

                    window.location.href = "home.html";
                })
                .catch(function () {
                    showMessage(loginMessage, "אירעה שגיאה בהתחברות לשרת", "error");
                });
        });
    }

    // הרשמה מול השרת
    if (registerForm) {
        registerForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const fullName = document.getElementById("registerFullName").value.trim();
            const username = document.getElementById("registerUsername").value.trim();
            const password = document.getElementById("registerPassword").value;
            const confirmPassword = document.getElementById("registerConfirmPassword").value;

            showMessage(registerMessage, "", "success");

            if (password !== confirmPassword) {
                showMessage(registerMessage, "הסיסמאות לא תואמות", "error");
                return;
            }

            fetch("/api/auth/register", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    fullName: fullName,
                    username: username,
                    password: password
                })
            })
                .then(function (response) {
                    return response.json();
                })
                .then(function (data) {
                    if (!data.success) {
                        showMessage(registerMessage, data.message, "error");
                        return;
                    }

                    localStorage.setItem("currentUser", JSON.stringify(data.user));

                    window.location.href = "home.html";
                })
                .catch(function () {
                    showMessage(registerMessage, "אירעה שגיאה בהרשמה לשרת", "error");
                });
        });
    }

});