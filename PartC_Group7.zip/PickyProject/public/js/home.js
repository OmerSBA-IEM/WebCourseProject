document.addEventListener("DOMContentLoaded", function () {

    const currentUser = JSON.parse(localStorage.getItem("currentUser"));

    if (!currentUser) {
        window.location.href = "index.html";
        return;
    }

    const welcomeUser = document.getElementById("welcomeUser");

    if (welcomeUser) {
        const userDisplayName =
            currentUser.fullName ||
            currentUser.full_name ||
            currentUser.username ||
            currentUser.name ||
            "משתמשת";

        welcomeUser.textContent = "ברוכה הבאה " + userDisplayName + ",";
    }

    const logoutBtn = document.getElementById("logoutBtn");

    if (logoutBtn) {
        logoutBtn.addEventListener("click", function (event) {
            event.preventDefault();

            localStorage.removeItem("currentUser");
            localStorage.removeItem("selectedCity");
            localStorage.removeItem("selectedRestaurantId");

            window.location.href = "index.html";
        });
    }

    const profilePreferencesText = document.getElementById("profilePreferencesText");
    const profilePreferencesTags = document.getElementById("profilePreferencesTags");
    const profilePreferencesNote = document.getElementById("profilePreferencesNote");
    const profilePreferencesLink = document.getElementById("profilePreferencesLink");

    const preferencesLabels = {
        "vegetarian": "צמחוני",
        "vegan": "טבעוני",
        "gluten-free": "ללא גלוטן",
        "lactose-free": "ללא לקטוז",
        "kosher": "כשר",

        "peanuts": "בוטנים",
        "milk": "חלב",
        "egg": "ביצים",
        "soy": "סויה",
        "sesame": "שומשום",
        "tree-nuts": "אגוזים",
        "fish": "דגים",

        "cilantro": "כוסברה",
        "tomato": "עגבנייה",
        "onion": "בצל",
        "garlic": "שום",
        "mushrooms": "פטריות",
        "eggplant": "חציל",
        "olives": "זיתים",
        "hot-pepper": "פלפל חריף",
        "bell-pepper": "פלפל אדום / גמבה",
        "cucumber": "מלפפון",
        "corn": "תירס",
        "peas": "אפונה",
        "mayonnaise": "מיונז",
        "mustard": "חרדל",
        "tuna": "טונה",
        "cinnamon": "קינמון",
        "dill": "שמיר",
        "parsley": "פטרוזיליה",
        "broccoli": "ברוקולי"
    };

    if (profilePreferencesTags) {
        loadUserPreferencesFromServer();
    }

    function loadUserPreferencesFromServer() {
        if (!currentUser.id) {
            renderEmptyPreferences();
            return;
        }

        fetch("/api/preferences/" + currentUser.id)
            .then(function (response) {
                return response.json();
            })
            .then(function (data) {
                if (!data.success) {
                    renderEmptyPreferences();
                    return;
                }

                renderPreferences(data.preferences);
            })
            .catch(function () {
                renderEmptyPreferences();
            });
    }

    function renderPreferences(preferences) {
        profilePreferencesTags.innerHTML = "";

        if (!preferences || preferences.length === 0) {
            renderEmptyPreferences();
            return;
        }

        if (profilePreferencesText) {
            profilePreferencesText.textContent = "אלו ההעדפות שנשמרו בפרופיל שלך:";
        }

        preferences.forEach(function (preference) {
            const tag = document.createElement("span");
            tag.classList.add("tag");

            if (preferencesLabels[preference.value]) {
                tag.textContent = preferencesLabels[preference.value];
            } else {
                tag.textContent = preference.value;
            }

            profilePreferencesTags.appendChild(tag);
        });

        if (profilePreferencesNote) {
            profilePreferencesNote.textContent = "נשתמש בהעדפות האלו כדי לסנן רכיבים ומנות שלא מתאימים לך.";
        }

        if (profilePreferencesLink) {
            profilePreferencesLink.innerHTML = `
                צפייה בכל ההעדפות
                <span>←</span>
            `;
        }
    }

    function renderEmptyPreferences() {
        if (profilePreferencesText) {
            profilePreferencesText.textContent = "עדיין לא הוזנו העדפות תזונתיות.";
        }

        if (profilePreferencesTags) {
            profilePreferencesTags.innerHTML = `
                <p class="empty-preferences-message">
                    עדיין לא הגדרת העדפות במערכת.
                </p>
            `;
        }

        if (profilePreferencesNote) {
            profilePreferencesNote.textContent = "כדי שנוכל להתאים לך מנות בצורה אישית, מומלץ לעדכן את ההעדפות שלך.";
        }

        if (profilePreferencesLink) {
            profilePreferencesLink.innerHTML = `
                מעבר לעמוד ההעדפות
                <span>←</span>
            `;
        }
    }

    const heroImage = document.getElementById("heroSliderImage");
    const dots = document.querySelectorAll(".dot");

    const images = [
        "images/home-slider/1.png",
        "images/home-slider/2.png",
        "images/home-slider/3.png",
        "images/home-slider/4.png",
        "images/home-slider/5.png",
        "images/home-slider/6.png",
        "images/home-slider/7.png",
        "images/home-slider/8.png"
    ];

    let currentImageIndex = 0;

    function changeImage() {
        currentImageIndex++;

        if (currentImageIndex === images.length) {
            currentImageIndex = 0;
        }

        heroImage.classList.add("fade-out");

        setTimeout(function () {
            heroImage.src = images[currentImageIndex];
            updateDots();
            heroImage.classList.remove("fade-out");
        }, 300);
    }

    function updateDots() {
        dots.forEach(function (dot, index) {
            if (index === currentImageIndex) {
                dot.classList.add("active-dot");
            } else {
                dot.classList.remove("active-dot");
            }
        });
    }

    if (heroImage) {
        setInterval(changeImage, 3000);
    }

});