const express = require('express');
const path = require('path');

// Route imports
const authRoutes = require('./server/routes/authRoutes');
const preferenceRoutes = require('./server/routes/preferenceRoutes');
const restaurantRoutes = require('./server/routes/restaurantRoutes');

// Initialize database connection
require('./server/db/database');

const app = express();
const PORT = 3000;

// Middleware for parsing requests
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// API route definitions
app.use('/api/auth', authRoutes);
app.use('/api/preferences', preferenceRoutes);
app.use('/api/restaurants', restaurantRoutes);

// Serve static frontend files
app.use(express.static(path.join(__dirname, 'public')));

// Fallback to index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});