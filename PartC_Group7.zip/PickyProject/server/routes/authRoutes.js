const express = require('express');
const router = express.Router();
const db = require('../db/database');

// Server status
router.get('/test', (req, res) => {
  res.json({
    message: 'Auth route is working'
  });
});

// User registration
router.post('/register', (req, res) => {
  const { fullName, username, password } = req.body;

  if (!fullName || !username || !password) {
    return res.status(400).json({
      success: false,
      message: 'יש להזין שם מלא, שם משתמש וסיסמה'
    });
  }

  const cleanFullName = fullName.trim();
  const cleanUsername = username.trim();

  if (cleanFullName.length === 0) {
    return res.status(400).json({
      success: false,
      message: 'שם מלא לא יכול להיות ריק'
    });
  }

// Input validation
  if (cleanFullName.length < 2) {
    return res.status(400).json({
      success: false,
      message: 'שם מלא חייב להכיל לפחות 2 תווים'
    });
  }

  if (cleanUsername.length === 0) {
    return res.status(400).json({
      success: false,
      message: 'שם משתמש לא יכול להיות ריק'
    });
  }

  if (cleanUsername.length < 3) {
    return res.status(400).json({
      success: false,
      message: 'שם המשתמש חייב להכיל לפחות 3 תווים'
    });
  }

  if (cleanUsername.length > 30) {
    return res.status(400).json({
      success: false,
      message: 'שם המשתמש יכול להכיל עד 30 תווים'
    });
  }

  if (password.length < 6) {
    return res.status(400).json({
      success: false,
      message: 'הסיסמה חייבת להכיל לפחות 6 תווים'
    });
  }

  if (password.length > 50) {
    return res.status(400).json({
      success: false,
      message: 'הסיסמה יכולה להכיל עד 50 תווים'
    });
  }

  const checkUserSql = `
    SELECT id
    FROM users
    WHERE username = ?
  `;

  db.get(checkUserSql, [cleanUsername], (err, user) => {
    if (err) {
      return res.status(500).json({
        success: false,
        message: 'שגיאה בבדיקת המשתמש'
      });
    }

    if (user) {
      return res.status(409).json({
        success: false,
        message: 'שם המשתמש כבר קיים במערכת'
      });
    }

    const insertUserSql = `
      INSERT INTO users (full_name, username, password)
      VALUES (?, ?, ?)
    `;

    db.run(insertUserSql, [cleanFullName, cleanUsername, password], function (err) {
      if (err) {
        return res.status(500).json({
          success: false,
          message: 'שגיאה ביצירת המשתמש'
        });
      }

      res.status(201).json({
        success: true,
        message: 'המשתמש נרשם בהצלחה',
        user: {
          id: this.lastID,
          fullName: cleanFullName,
          username: cleanUsername
        }
      });
    });
  });
});

// User login
router.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({
      success: false,
      message: 'יש להזין שם משתמש וסיסמה'
    });
  }

  const cleanUsername = username.trim();

  if (cleanUsername.length === 0) {
    return res.status(400).json({
      success: false,
      message: 'שם משתמש לא יכול להיות ריק'
    });
  }

  if (cleanUsername.length < 3) {
    return res.status(400).json({
      success: false,
      message: 'שם המשתמש חייב להכיל לפחות 3 תווים'
    });
  }

  if (password.length < 6) {
    return res.status(400).json({
      success: false,
      message: 'הסיסמה חייבת להכיל לפחות 6 תווים'
    });
  }

  const loginSql = `
    SELECT id, full_name, username
    FROM users
    WHERE username = ? AND password = ?
  `;

  db.get(loginSql, [cleanUsername, password], (err, user) => {
    if (err) {
      return res.status(500).json({
        success: false,
        message: 'שגיאה בהתחברות'
      });
    }

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'שם משתמש או סיסמה שגויים'
      });
    }

    res.json({
      success: true,
      message: 'התחברת בהצלחה',
      user: {
        id: user.id,
        fullName: user.full_name,
        username: user.username
      }
    });
  });
});

module.exports = router;