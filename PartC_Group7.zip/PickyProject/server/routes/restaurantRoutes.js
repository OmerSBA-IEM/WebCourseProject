const express = require('express');
const router = express.Router();
const db = require('../db/database');

const allowedCities = ['beer-sheva', 'haifa', 'ashdod', 'tel-aviv'];

// Promise-based wrappers for database operations
function dbAll(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) {
        reject(err);
      } else {
        resolve(rows);
      }
    });
  });
}

function dbGet(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) {
        reject(err);
      } else {
        resolve(row);
      }
    });
  });
}

// Server status
router.get('/test', (req, res) => {
  res.json({
    message: 'Restaurant route is working'
  });
});

// Fetch filtered restaurant list
router.get('/', async (req, res) => {
  const city = req.query.city;
  const userId = req.query.userId;

  if (!city) {
    return res.status(400).json({
      success: false,
      message: 'יש לבחור עיר'
    });
  }

  if (!allowedCities.includes(city)) {
    return res.status(400).json({
      success: false,
      message: 'העיר שנבחרה אינה נתמכת במערכת'
    });
  }

  try {
    const restaurants = await dbAll(`
      SELECT 
        restaurants.id,
        restaurants.name,
        restaurants.cuisine,
        restaurants.description,
        restaurants.logo,
        restaurant_locations.city,
        restaurant_locations.address
      FROM restaurants
      INNER JOIN restaurant_locations
        ON restaurants.id = restaurant_locations.restaurant_id
      WHERE restaurant_locations.city = ?
      ORDER BY restaurants.name
    `, [city]);

    if (!userId) {
      return res.json({
        success: true,
        restaurants: restaurants
      });
    }

    // Calculate relevant dishes count based on user preferences
    const numericUserId = Number(userId);

    if (!Number.isInteger(numericUserId) || numericUserId <= 0) {
      return res.status(400).json({
        success: false,
        message: 'מזהה המשתמש אינו תקין'
      });
    }

    const user = await dbGet(`
      SELECT id
      FROM users
      WHERE id = ?
    `, [numericUserId]);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'המשתמש לא נמצא'
      });
    }

    const userPreferences = await getUserPreferences(numericUserId);
    const restaurantsWithRelevantCount = [];

    for (const restaurant of restaurants) {
      const dishes = await getDishesByRestaurantId(restaurant.id);

      const relevantDishes = dishes.filter((dish) => {
        return isDishRelevantForUser(dish, userPreferences);
      });

      restaurantsWithRelevantCount.push({
        ...restaurant,
        relevantDishesCount: relevantDishes.length
      });
    }

    res.json({
      success: true,
      restaurants: restaurantsWithRelevantCount
    });

  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'שגיאה בשליפת המסעדות'
    });
  }
});

// Fetch relevant menu for a specific restaurant
router.get('/:id/menu/relevant', async (req, res) => {
  const restaurantId = req.params.id;
  const userId = req.query.userId;

  const numericRestaurantId = Number(restaurantId);

  if (!Number.isInteger(numericRestaurantId) || numericRestaurantId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'מזהה המסעדה אינו תקין'
    });
  }

  if (!userId) {
    return res.status(400).json({
      success: false,
      message: 'חסר מזהה משתמש'
    });
  }

  const numericUserId = Number(userId);

  if (!Number.isInteger(numericUserId) || numericUserId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'מזהה המשתמש אינו תקין'
    });
  }

  try {
    const restaurant = await getRestaurantById(numericRestaurantId);

    if (!restaurant) {
      return res.status(404).json({
        success: false,
        message: 'המסעדה לא נמצאה'
      });
    }

    const user = await dbGet(`
      SELECT id
      FROM users
      WHERE id = ?
    `, [numericUserId]);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'המשתמש לא נמצא'
      });
    }

    const dishes = await getDishesByRestaurantId(numericRestaurantId);
    const userPreferences = await getUserPreferences(numericUserId);

    const relevantDishes = dishes.filter((dish) => {
      return isDishRelevantForUser(dish, userPreferences);
    });

    res.json({
      success: true,
      restaurant: restaurant,
      userPreferences: userPreferences,
      dishes: relevantDishes
    });

  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'שגיאה בשליפת התפריט הרלוונטי'
    });
  }
});

// Fetch full restaurant menu
router.get('/:id/menu', async (req, res) => {
  const restaurantId = req.params.id;
  const numericRestaurantId = Number(restaurantId);

  if (!Number.isInteger(numericRestaurantId) || numericRestaurantId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'מזהה המסעדה אינו תקין'
    });
  }

  try {
    const restaurant = await getRestaurantById(numericRestaurantId);

    if (!restaurant) {
      return res.status(404).json({
        success: false,
        message: 'המסעדה לא נמצאה'
      });
    }

    const dishes = await getDishesByRestaurantId(numericRestaurantId);

    res.json({
      success: true,
      restaurant: restaurant,
      dishes: dishes
    });

  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'שגיאה בשליפת התפריט'
    });
  }
});

// Fetch restaurant details
router.get('/:id', async (req, res) => {
  const restaurantId = req.params.id;
  const numericRestaurantId = Number(restaurantId);

  if (!Number.isInteger(numericRestaurantId) || numericRestaurantId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'מזהה המסעדה אינו תקין'
    });
  }

  try {
    const restaurant = await getRestaurantById(numericRestaurantId);

    if (!restaurant) {
      return res.status(404).json({
        success: false,
        message: 'המסעדה לא נמצאה'
      });
    }

    res.json({
      success: true,
      restaurant: restaurant
    });

  } catch (err) {
    res.status(500).json({
      success: false,
      message: 'שגיאה בשליפת המסעדה'
    });
  }
});

// Database helper functions
async function getRestaurantById(restaurantId) {
  const restaurant = await dbGet(`
    SELECT id, name, cuisine, description, logo
    FROM restaurants
    WHERE id = ?
  `, [restaurantId]);

  return restaurant;
}

async function getDishesByRestaurantId(restaurantId) {
  const dishesRows = await dbAll(`
    SELECT id, restaurant_id, name, category, description, price, image
    FROM dishes
    WHERE restaurant_id = ?
    ORDER BY category, name
  `, [restaurantId]);

  const dishes = [];

  for (const dish of dishesRows) {
    const dietaryRows = await dbAll(`
      SELECT dietary_value
      FROM dish_dietary
      WHERE dish_id = ?
    `, [dish.id]);

    const allergenRows = await dbAll(`
      SELECT allergen_value
      FROM dish_allergens
      WHERE dish_id = ?
    `, [dish.id]);

    const ingredientRows = await dbAll(`
      SELECT ingredient_value
      FROM dish_ingredients
      WHERE dish_id = ?
    `, [dish.id]);

    const notesRows = await dbAll(`
      SELECT note_text, note_keys
      FROM dish_customization_notes
      WHERE dish_id = ?
    `, [dish.id]);

    const notes = notesRows.map((note) => {
      let keys = [];

      try {
        keys = JSON.parse(note.note_keys);
      } catch (error) {
        keys = [];
      }

      return {
        text: note.note_text,
        keys: keys
      };
    });

    dishes.push({
      id: dish.id,
      restaurantId: dish.restaurant_id,
      name: dish.name,
      category: dish.category,
      description: dish.description,
      price: dish.price,
      image: dish.image,
      dietary: dietaryRows.map((row) => row.dietary_value),
      allergens: allergenRows.map((row) => row.allergen_value),
      ingredients: ingredientRows.map((row) => row.ingredient_value),
      notes: notes
    });
  }

  return dishes;
}

async function getUserPreferences(userId) {
  const preferencesRows = await dbAll(`
    SELECT preference_type, preference_value
    FROM user_preferences
    WHERE user_id = ?
  `, [userId]);

  const userPreferences = {
    dietary: [],
    allergens: [],
    dislikes: []
  };

  preferencesRows.forEach((preference) => {
    if (preference.preference_type === 'dietary') {
      userPreferences.dietary.push(preference.preference_value);
    }

    if (preference.preference_type === 'allergens') {
      userPreferences.allergens.push(preference.preference_value);
    }

    if (preference.preference_type === 'dislikes') {
      userPreferences.dislikes.push(preference.preference_value);
    }
  });

  return userPreferences;
}

// Preference filtering logic
function isDishRelevantForUser(dish, userPreferences) {
  const userKeys = getAllUserPreferenceKeys(userPreferences);

  if (userKeys.length === 0) {
    return true;
  }

  const dietaryIsOk = userPreferences.dietary.every((preference) => {
    return dish.dietary.includes(preference) || hasNoteForPreference(dish, preference);
  });

  const allergenKeys = getRelevantAllergenKeys(userPreferences);

  const allergensAreOk = allergenKeys.every((allergen) => {
    const dishHasAllergen = dish.allergens.includes(allergen);

    if (!dishHasAllergen) {
      return true;
    }

    return hasNoteForPreference(dish, allergen);
  });

  const dislikesAreOk = userPreferences.dislikes.every((dislike) => {
    const dishHasDislike = dish.ingredients.includes(dislike);

    if (!dishHasDislike) {
      return true;
    }

    return hasNoteForPreference(dish, dislike);
  });

  return dietaryIsOk && allergensAreOk && dislikesAreOk;
}

function getAllUserPreferenceKeys(userPreferences) {
  return [
    ...userPreferences.dietary,
    ...userPreferences.allergens,
    ...userPreferences.dislikes
  ];
}

function hasNoteForPreference(dish, preferenceKey) {
  return dish.notes.some((note) => {
    return note.keys.includes(preferenceKey);
  });
}

function getRelevantAllergenKeys(userPreferences) {
  const userKeys = getAllUserPreferenceKeys(userPreferences);
  const relevantAllergens = [...userPreferences.allergens];

  if (userKeys.includes('lactose-free')) {
    relevantAllergens.push('milk');
  }

  if (userKeys.includes('gluten-free')) {
    relevantAllergens.push('gluten');
  }

  return relevantAllergens;
}

module.exports = router;