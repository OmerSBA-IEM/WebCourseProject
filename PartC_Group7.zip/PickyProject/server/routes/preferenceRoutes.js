const express = require('express');
const router = express.Router();
const db = require('../db/database');

// Allowed preference categories
const allowedPreferenceTypes = ['dietary', 'allergens', 'dislikes'];

// Server status
router.get('/test', (req, res) => {
  res.json({
    message: 'Preference route is working'
  });
});

// Save user preferences
router.post('/save', (req, res) => {
  const { userId, preferences } = req.body;

  // Validation: Check userId
  if (!userId) {
    return res.status(400).json({
      success: false,
      message: 'חסר מזהה משתמש'
    });
  }

  const numericUserId = Number(userId);

  // Validation: Check numeric format
  if (!Number.isInteger(numericUserId) || numericUserId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'מזהה המשתמש אינו תקין'
    });
  }

 // Validation: Ensure array format and size limit
  if (!Array.isArray(preferences)) {
    return res.status(400).json({
      success: false,
      message: 'רשימת ההעדפות אינה תקינה'
    });
  }

  if (preferences.length > 50) {
    return res.status(400).json({
      success: false,
      message: 'ניתן לשמור עד 50 העדפות בלבד'
    });
  }

  const duplicateCheck = new Set();

  for (const preference of preferences) {
    if (!preference || typeof preference !== 'object') {
      return res.status(400).json({
        success: false,
        message: 'כל העדפה חייבת להיות אובייקט תקין'
      });
    }

    const type = preference.type;
    const value = preference.value;

    if (!type || !value) {
      return res.status(400).json({
        success: false,
        message: 'כל העדפה חייבת להכיל סוג וערך'
      });
    }

    if (typeof type !== 'string' || typeof value !== 'string') {
      return res.status(400).json({
        success: false,
        message: 'סוג וערך ההעדפה חייבים להיות טקסט'
      });
    }

    const cleanType = type.trim();
    const cleanValue = value.trim();

    if (cleanType.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'סוג ההעדפה לא יכול להיות ריק'
      });
    }

    if (cleanValue.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'ערך ההעדפה לא יכול להיות ריק'
      });
    }

    if (!allowedPreferenceTypes.includes(cleanType)) {
      return res.status(400).json({
        success: false,
        message: 'סוג ההעדפה אינו תקין'
      });
    }

    if (cleanValue.length > 40) {
      return res.status(400).json({
        success: false,
        message: 'ערך ההעדפה ארוך מדי'
      });
    }

    const duplicateKey = cleanType + ':' + cleanValue;

    if (duplicateCheck.has(duplicateKey)) {
      return res.status(400).json({
        success: false,
        message: 'לא ניתן לשמור את אותה העדפה פעמיים'
      });
    }

    duplicateCheck.add(duplicateKey);
  }

  // Verify user exists
  const checkUserSql = `
    SELECT id
    FROM users
    WHERE id = ?
  `;

  db.get(checkUserSql, [numericUserId], (err, user) => {
    if (err) {
      return res.status(500).json({
        success: false,
        message: 'שגיאה בבדיקת המשתמש'
      });
    }

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'המשתמש לא נמצא'
      });
    }

    // Clear existing preferences and insert new ones
    const deleteOldPreferencesSql = `
      DELETE FROM user_preferences
      WHERE user_id = ?
    `;

    db.run(deleteOldPreferencesSql, [numericUserId], (err) => {
      if (err) {
        return res.status(500).json({
          success: false,
          message: 'שגיאה במחיקת ההעדפות הישנות'
        });
      }

      // אם המשתמש לא בחר כלום, נשאיר אותו בלי העדפות
      if (preferences.length === 0) {
        return res.json({
          success: true,
          message: 'ההעדפות נמחקו בהצלחה'
        });
      }

      const insertPreferenceSql = `
        INSERT INTO user_preferences (user_id, preference_type, preference_value)
        VALUES (?, ?, ?)
      `;

      const statement = db.prepare(insertPreferenceSql);

      for (const preference of preferences) {
        statement.run([
          numericUserId,
          preference.type.trim(),
          preference.value.trim()
        ]);
      }

      statement.finalize((err) => {
        if (err) {
          return res.status(500).json({
            success: false,
            message: 'שגיאה בשמירת ההעדפות'
          });
        }

        res.json({
          success: true,
          message: 'ההעדפות נשמרו בהצלחה'
        });
      });
    });
  });
});

// Retrieve user preferences
router.get('/:userId', (req, res) => {
  const userId = req.params.userId;

  const numericUserId = Number(userId);

  if (!Number.isInteger(numericUserId) || numericUserId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'מזהה המשתמש אינו תקין'
    });
  }

  const checkUserSql = `
    SELECT id
    FROM users
    WHERE id = ?
  `;

  db.get(checkUserSql, [numericUserId], (err, user) => {
    if (err) {
      return res.status(500).json({
        success: false,
        message: 'שגיאה בבדיקת המשתמש'
      });
    }

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'המשתמש לא נמצא'
      });
    }

    const getPreferencesSql = `
      SELECT preference_type, preference_value
      FROM user_preferences
      WHERE user_id = ?
    `;

    db.all(getPreferencesSql, [numericUserId], (err, rows) => {
      if (err) {
        return res.status(500).json({
          success: false,
          message: 'שגיאה בשליפת ההעדפות'
        });
      }

      const preferences = rows.map((row) => {
        return {
          type: row.preference_type,
          value: row.preference_value
        };
      });

      res.json({
        success: true,
        preferences: preferences
      });
    });
  });
});

// Delete all user preferences
router.delete('/:userId', (req, res) => {
  const userId = req.params.userId;

  const numericUserId = Number(userId);

  if (!Number.isInteger(numericUserId) || numericUserId <= 0) {
    return res.status(400).json({
      success: false,
      message: 'מזהה המשתמש אינו תקין'
    });
  }

  const checkUserSql = `
    SELECT id
    FROM users
    WHERE id = ?
  `;

  db.get(checkUserSql, [numericUserId], (err, user) => {
    if (err) {
      return res.status(500).json({
        success: false,
        message: 'שגיאה בבדיקת המשתמש'
      });
    }

    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'המשתמש לא נמצא'
      });
    }

    const deletePreferencesSql = `
      DELETE FROM user_preferences
      WHERE user_id = ?
    `;

    db.run(deletePreferencesSql, [numericUserId], (err) => {
      if (err) {
        return res.status(500).json({
          success: false,
          message: 'שגיאה במחיקת ההעדפות'
        });
      }

      res.json({
        success: true,
        message: 'ההעדפות נמחקו בהצלחה'
      });
    });
  });
});

module.exports = router;