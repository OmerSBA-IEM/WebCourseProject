const fs = require("fs");
const path = require("path");
const vm = require("vm");

// Load raw data from the frontend file
const dataPath = path.join(__dirname, "../../public/js/data.js");
const dataFileContent = fs.readFileSync(dataPath, "utf8");

// Execute data.js in a sandboxed context to extract restaurantsData
const restaurantsData = vm.runInNewContext(
  dataFileContent + "\nrestaurantsData;",
  { console },
  { filename: "data.js" }
);

// Export for database initialization
module.exports = restaurantsData;