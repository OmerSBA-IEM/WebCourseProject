console.log("Database file loaded");

const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const restaurantsData = require("./seedData");

// Path to database file
const dbPath = path.join(__dirname, "picky.db");

// Initialize database connection
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error("Error connecting to database:", err.message);
  } else {
    console.log("Connected to SQLite database");
  }
});

db.serialize(() => {

  // Create users table
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL DEFAULT '',
      username TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL
    )
  `, (err) => {
    if (err) {
      console.error("Error creating users table:", err.message);
    } else {
      console.log("Users table is ready");
    }
  });

  // Ensure full_name column exists (migration check)
  db.all(`PRAGMA table_info(users)`, (err, columns) => {
    if (err) {
      console.error("Error checking users table columns:", err.message);
      return;
    }

    const hasFullNameColumn = columns.some((column) => column.name === "full_name");

    if (!hasFullNameColumn) {
      db.run(`ALTER TABLE users ADD COLUMN full_name TEXT DEFAULT ''`, (err) => {
        if (err) {
          console.error("Error adding full_name column:", err.message);
        } else {
          console.log("full_name column added to users table");
        }
      });
    } else {
      console.log("full_name column already exists");
    }
  });

  // Create user preferences table
  db.run(`
    CREATE TABLE IF NOT EXISTS user_preferences (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      preference_type TEXT NOT NULL,
      preference_value TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `, (err) => {
    if (err) {
      console.error("Error creating user_preferences table:", err.message);
    } else {
      console.log("User preferences table is ready");
    }
  });

  // Create restaurants and locations tables
  db.run(`
    CREATE TABLE IF NOT EXISTS restaurants (
      id INTEGER PRIMARY KEY,
      name TEXT NOT NULL,
      cuisine TEXT NOT NULL,
      description TEXT NOT NULL,
      logo TEXT NOT NULL
    )
  `, (err) => {
    if (err) {
      console.error("Error creating restaurants table:", err.message);
    } else {
      console.log("Restaurants table is ready");
    }
  });

  db.run(`
    CREATE TABLE IF NOT EXISTS restaurant_locations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      restaurant_id INTEGER NOT NULL,
      city TEXT NOT NULL,
      address TEXT NOT NULL,
      FOREIGN KEY (restaurant_id) REFERENCES restaurants(id)
    )
  `, (err) => {
    if (err) {
      console.error("Error creating restaurant_locations table:", err.message);
    } else {
      console.log("Restaurant locations table is ready");
    }
  });

  // Create dishes and related attribute tables
  db.run(`
    CREATE TABLE IF NOT EXISTS dishes (
      id INTEGER PRIMARY KEY,
      restaurant_id INTEGER NOT NULL,
      name TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      price INTEGER NOT NULL,
      image TEXT NOT NULL,
      FOREIGN KEY (restaurant_id) REFERENCES restaurants(id)
    )
  `, (err) => {
    if (err) {
      console.error("Error creating dishes table:", err.message);
    } else {
      console.log("Dishes table is ready");
    }
  });

  db.run(`
    CREATE TABLE IF NOT EXISTS dish_dietary (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      dish_id INTEGER NOT NULL,
      dietary_value TEXT NOT NULL,
      FOREIGN KEY (dish_id) REFERENCES dishes(id)
    )
  `, (err) => {
    if (err) {
      console.error("Error creating dish_dietary table:", err.message);
    } else {
      console.log("Dish dietary table is ready");
    }
  });

  db.run(`
    CREATE TABLE IF NOT EXISTS dish_allergens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      dish_id INTEGER NOT NULL,
      allergen_value TEXT NOT NULL,
      FOREIGN KEY (dish_id) REFERENCES dishes(id)
    )
  `, (err) => {
    if (err) {
      console.error("Error creating dish_allergens table:", err.message);
    } else {
      console.log("Dish allergens table is ready");
    }
  });

  db.run(`
    CREATE TABLE IF NOT EXISTS dish_ingredients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      dish_id INTEGER NOT NULL,
      ingredient_value TEXT NOT NULL,
      FOREIGN KEY (dish_id) REFERENCES dishes(id)
    )
  `, (err) => {
    if (err) {
      console.error("Error creating dish_ingredients table:", err.message);
    } else {
      console.log("Dish ingredients table is ready");
    }
  });

  db.run(`
    CREATE TABLE IF NOT EXISTS dish_customization_notes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      dish_id INTEGER NOT NULL,
      note_text TEXT NOT NULL,
      note_keys TEXT NOT NULL,
      FOREIGN KEY (dish_id) REFERENCES dishes(id)
    )
  `, (err) => {
    if (err) {
      console.error("Error creating dish_customization_notes table:", err.message);
    } else {
      console.log("Dish customization notes table is ready");
    }
  });

  seedRestaurantsAndDishes();

});

// Populate database with seed data
function seedRestaurantsAndDishes() {
// Clear tables to avoid duplication
  db.run(`DELETE FROM dish_customization_notes`);
  db.run(`DELETE FROM dish_ingredients`);
  db.run(`DELETE FROM dish_allergens`);
  db.run(`DELETE FROM dish_dietary`);
  db.run(`DELETE FROM dishes`);
  db.run(`DELETE FROM restaurant_locations`);
  db.run(`DELETE FROM restaurants`);

  const insertRestaurantSql = `
    INSERT INTO restaurants (id, name, cuisine, description, logo)
    VALUES (?, ?, ?, ?, ?)
  `;

  const insertLocationSql = `
    INSERT INTO restaurant_locations (restaurant_id, city, address)
    VALUES (?, ?, ?)
  `;

  const insertDishSql = `
    INSERT INTO dishes (id, restaurant_id, name, category, description, price, image)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `;

  const insertDietarySql = `
    INSERT INTO dish_dietary (dish_id, dietary_value)
    VALUES (?, ?)
  `;

  const insertAllergenSql = `
    INSERT INTO dish_allergens (dish_id, allergen_value)
    VALUES (?, ?)
  `;

  const insertIngredientSql = `
    INSERT INTO dish_ingredients (dish_id, ingredient_value)
    VALUES (?, ?)
  `;

  const insertNoteSql = `
    INSERT INTO dish_customization_notes (dish_id, note_text, note_keys)
    VALUES (?, ?, ?)
  `;

  const restaurantStatement = db.prepare(insertRestaurantSql);
  const locationStatement = db.prepare(insertLocationSql);
  const dishStatement = db.prepare(insertDishSql);
  const dietaryStatement = db.prepare(insertDietarySql);
  const allergenStatement = db.prepare(insertAllergenSql);
  const ingredientStatement = db.prepare(insertIngredientSql);
  const noteStatement = db.prepare(insertNoteSql);

  safeArray(restaurantsData).forEach((restaurant) => {

    restaurantStatement.run([
      restaurant.id,
      restaurant.name,
      restaurant.cuisine,
      restaurant.description,
      restaurant.logo
    ]);

    safeArray(restaurant.cities).forEach((city) => {
      locationStatement.run([
        restaurant.id,
        city,
        restaurant.address && restaurant.address[city] ? restaurant.address[city] : "כתובת לא זמינה"
      ]);
    });

    safeArray(restaurant.menu).forEach((dish) => {

      dishStatement.run([
        dish.dishId,
        restaurant.id,
        dish.name,
        dish.category,
        dish.description,
        dish.price,
        dish.image
      ]);

      safeArray(dish.dietary).forEach((dietaryValue) => {
        dietaryStatement.run([
          dish.dishId,
          dietaryValue
        ]);
      });

      safeArray(dish.allergens).forEach((allergenValue) => {
        allergenStatement.run([
          dish.dishId,
          allergenValue
        ]);
      });

      safeArray(dish.ingredients).forEach((ingredientValue) => {
        ingredientStatement.run([
          dish.dishId,
          ingredientValue
        ]);
      });

      const notes = getDishNotes(dish);

      notes.forEach((note) => {
        noteStatement.run([
          dish.dishId,
          note.text,
          JSON.stringify(note.keys)
        ]);
      });

    });

  });

  restaurantStatement.finalize();
  locationStatement.finalize();
  dishStatement.finalize();
  dietaryStatement.finalize();
  allergenStatement.finalize();
  ingredientStatement.finalize();

  noteStatement.finalize((err) => {
    if (err) {
      console.error("Error inserting seed data:", err.message);
    } else {
      console.log("All restaurants and dishes data inserted");
    }
  });
}

// Utility for array safety
function safeArray(value) {
  if (Array.isArray(value)) {
    return value;
  }

  return [];
}

// Parse and normalize customization notes
function getDishNotes(dish) {
  const rawNotes =
    dish.customization &&
    Array.isArray(dish.customization.notes)
      ? dish.customization.notes
      : [];

  return rawNotes
    .map((note) => {
      if (Array.isArray(note)) {
        return {
          text: note[0],
          keys: note.slice(1)
        };
      }

      if (note && note.text) {
        return {
          text: note.text,
          keys: Array.isArray(note.keys) ? note.keys : []
        };
      }

      return null;
    })
    .filter((note) => {
      return note && note.text && Array.isArray(note.keys);
    });
}
module.exports = db;